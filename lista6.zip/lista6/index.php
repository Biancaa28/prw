<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
</head>
<body>

    <h1>AGENDA - Menu Principal</h1>
    <div id="menu">
        <ul>
            <li><a href="cadastro_agenda.html">Cadastro Agenda</a></li>
            <li><a href="listar_agenda.php">Listagem da Agenda</a></li>
        </ul>
    </div>

</body>
</html>